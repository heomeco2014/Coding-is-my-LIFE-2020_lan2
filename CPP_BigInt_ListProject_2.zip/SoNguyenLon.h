#ifndef SONGUYENLON_H
#define SONGUYENLON_H
#include "LinkedList.h"
using namespace std;

class SoNguyenLon {
  friend SoNguyenLon operator+(const SoNguyenLon& n1, const SoNguyenLon& n2);
  friend SoNguyenLon operator-(const SoNguyenLon& n1, const SoNguyenLon& n2);
  friend SoNguyenLon operator*(const SoNguyenLon& n1, const SoNguyenLon& n2);
  friend ostream& operator<<(ostream& os, const SoNguyenLon& n);
public:
  SoNguyenLon();
  SoNguyenLon(long n);
  SoNguyenLon(int d, long n);
  SoNguyenLon(const LinkedList& src);
  SoNguyenLon(const SoNguyenLon& other);
  virtual ~SoNguyenLon();
  const SoNguyenLon& operator=(const SoNguyenLon& right);
  int compareValue(const SoNguyenLon& right) const;
  static SoNguyenLon SNLMax();
private:
  LinkedList list;
  static SoNguyenLon max;
};
#endif /* SONGUYENLON_H */
