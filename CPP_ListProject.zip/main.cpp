#include <iostream>
#include <cstdlib>
#include <ctime>
#include "LinkedList.h"
using namespace std;

int main() {
  srand(time(NULL));
  LinkedList l;
  for (int i = 0; i < 10; ++i) {
    if (rand()%2 == 0) l.addHead(rand() % 1001);
    else l.addTail(rand() % 1001);
  }
  cout << l << endl;
  l.removeHead();
  l.removeTail();
  l[-1] = 9000;
  l[4] = 2000;
  l[100] = 10000;
  cout << l << endl;
  return 0;
}
