#include "SoNguyenLon.h"
#include <sstream>
SoNguyenLon SoNguyenLon::max = SoNguyenLon();

SoNguyenLon::SoNguyenLon() {
  list.addTail(0);
}

SoNguyenLon::SoNguyenLon(long n) {
  do list.addHead(n % 10); while (n /= 10);
  if (compareValue(max) > 0) max = *this;
}

SoNguyenLon::SoNguyenLon(int d, long n) {
  for (long i = 0; i < n; ++i)
    list.addHead(d % 10);
  if (compareValue(max) > 0) max = *this;
}

SoNguyenLon::SoNguyenLon(const LinkedList& src) {
  list = src;
  if (compareValue(max) > 0) max = *this;
}

SoNguyenLon::SoNguyenLon(const SoNguyenLon& other) {
  list = other.list;
  if (compareValue(max) > 0) max = *this;
}

SoNguyenLon::~SoNguyenLon() { }

SoNguyenLon operator+(const SoNguyenLon& n1, const SoNguyenLon& n2) {
  int c = 0;
  LinkedList r;
  LinkedList l1(n1.list);
  LinkedList l2(n2.list);
  while (!l1.isEmpty() && !l2.isEmpty()) {
    c = l1.removeTail()->info + l2.removeTail()->info + c;
    r.addHead(c % 10);
    c /= 10;
  }
  while (!l1.isEmpty()) {
    c = l1.removeTail()->info + c;
    r.addHead(c % 10);
    c /= 10;
  }
  while (!l2.isEmpty() > 0) {
    c = l2.removeTail()->info + c;
    r.addHead(c % 10);
    c /= 10;
  }
  if (c) r.addHead(1);
  return SoNguyenLon(r);
}

void subtract(int& c, LinkedList& r){
  if (c < 0) {
    r.addHead((10 + c) % 10);
    c = 1;
  } else {
    r.addHead(c % 10);
    c = 0;
  }
}

SoNguyenLon operator-(const SoNguyenLon & n1, const SoNguyenLon & n2) {
  if (n1.compareValue(n2) <= 0) return SoNguyenLon();
  int c = 0;
  LinkedList r;
  LinkedList l1(n1.list);
  LinkedList l2(n2.list);
  while (!l1.isEmpty() && !l2.isEmpty()) {
    c = (l1.removeTail()->info) - ((l2.removeTail()->info) + c);
    subtract(c, r);
  }
  while (!l1.isEmpty()) {
    c = l1.removeTail()->info - c;
    subtract(c, r);
  }
  while (!l2.isEmpty()) {
    c = l2.removeTail()->info - c;
    subtract(c, r);
  }
  return SoNguyenLon(r);
}

SoNguyenLon operator*(const SoNguyenLon & n1, const SoNguyenLon & n2) {
  LinkedList r;
  LinkedList l1(n1.list);
  LinkedList l2(n2.list);
  int i, j, k, n, m, c;
  i = l1.getSize() - 1;  
  j = l2.getSize() - 1;
  n = i + j;
  c = 0;
  for (k = n; k >= 0; --k) {
    for (m = k; m >= 0; --m)
      if (m <= i && (k - m) <= j)
        c += l1[m] * l2[k - m];
    r.addHead(c % 10);
    c /= 10;
  }
  if (c) r.addHead(c);
  return SoNguyenLon(r);
}

const SoNguyenLon & SoNguyenLon::operator=(const SoNguyenLon & right) {
  if (this == &right) return *this;
  list = right.list;
  return *this;
}

SoNguyenLon SoNguyenLon::SNLMax() {
  return max;
}

ostream& operator<<(ostream& os, const SoNguyenLon& n) {
  os << n.list;
  return os;
}

int SoNguyenLon::compareValue(const SoNguyenLon& right) const {
  if (list.getSize() > right.list.getSize()) return 1;
  if (list.getSize() < right.list.getSize()) return -1;
  LinkedList l1(list);
  LinkedList l2(right.list);
  while (!l1.isEmpty() && l1[0] == l2[0]) {
    l1.removeHead();
    l2.removeHead();
  } 
  if (l1.isEmpty()) return 0;
  if (l1[0] > l2[0]) return 1;
  if (l1[0] < l2[0]) return -1;
}
