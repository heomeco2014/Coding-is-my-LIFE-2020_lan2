Em chào thầy ạ. 
Em là Hoàng Nhật Minh, mssv: 20127239
Bị cúp điện nên giờ em nộp trễ ạ